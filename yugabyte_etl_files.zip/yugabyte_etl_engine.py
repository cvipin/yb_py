#!/usr/bin/env python3
"""
yugabyte_etl_engine.py
═══════════════════════════════════════════════════════════════════════════════
YugabyteDB Parallel ETL Engine  —  250 M+ record bulk loader
5-node RF-3 cluster · 16 worker threads · Robust connection pooling
═══════════════════════════════════════════════════════════════════════════════

INSTALLATION
─────────────────────────────────────────────────────────────────────────────
  # YugabyteDB Smart Driver (psycopg2 fork — required for load_balance /
  # topology_keys / automatic node-failover)
  pip install psycopg2-yugabyte

  # Fallback: plain psycopg2 works too; load_balance param is simply ignored
  pip install psycopg2-binary

WHAT THIS SOLVES
─────────────────────────────────────────────────────────────────────────────
  Problem 1 – TCP silent-drop on idle connections
    → TCP keepalive probes (keepalives / keepalives_idle /
      keepalives_interval / keepalives_count) keep every connection alive.

  Problem 2 – Stale / dead connection returned from pool
    → Every acquire() runs a two-stage health check (Python conn.closed flag
      + lightweight SELECT 1 ping) before handing the connection to a thread.
      Dead connections are replaced on-the-fly; the thread never sees them.

  Problem 3 – Pool exhausted under 16-thread load
    → Pool is sized pool_max=24 (16 workers + 8 headroom).  Threads that
      cannot get a slot within `acquire_timeout` seconds get a fresh
      on-demand connection instead of an error.

  Problem 4 – Single-node failure in 5-node cluster
    → The Smart Driver DSN lists all 5 hosts.  On connect() or reconnect()
      the driver round-robins across live nodes automatically.

  Problem 5 – YugabyteDB serialisation / deadlock retries
    → _with_retry() wraps every batch operation with exponential-backoff
      retries for SerializationFailure and DeadlockDetected.

OPERATION MODES (per Batch)
─────────────────────────────────────────────────────────────────────────────
  INSERT  — PostgreSQL COPY FROM STDIN (fastest possible, no row-by-row round
            trips; handles NULL, tab, newline, backslash in values correctly)
  UPSERT  — INSERT … ON CONFLICT (conflict_cols) DO UPDATE SET …
            via psycopg2.extras.execute_values
  UPDATE  — CREATE TEMP TABLE + COPY data in + UPDATE … FROM temp
            (much faster than N individual UPDATE statements)
  DELETE  — CREATE TEMP TABLE + COPY keys in + DELETE … USING temp
            (or DELETE WHERE col = ANY(%s) for single-key batches ≤ 50 k)
"""

from __future__ import annotations

import csv
import io
import logging
import queue
import select as _select
import threading
import time
from contextlib import contextmanager
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, Generator, List, Optional, Tuple

import psycopg2
import psycopg2.errors
import psycopg2.extensions
import psycopg2.extras

# ─────────────────────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(threadName)-22s] %(levelname)-8s %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("yb_etl")


# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ClusterConfig:
    """
    All tuneable settings for the 5-node YugabyteDB cluster.

    Topology note
    ─────────────
    topology_keys uses the format  "cloud.region.zone"  where '*' is a
    wildcard.  Examples:
        "aws.us-east-1.*"           — any AZ in us-east-1
        "aws.us-east-1.us-east-1a" — pin to one AZ
        ""                          — disable topology-aware routing
    """

    # ── Nodes ─────────────────────────────────────────────────────────────────
    hosts: List[str] = field(default_factory=lambda: [
        "yb-node-1.example.com",
        "yb-node-2.example.com",
        "yb-node-3.example.com",
        "yb-node-4.example.com",
        "yb-node-5.example.com",
    ])
    port: int = 5433          # YugabyteDB YSQL port (PostgreSQL-compatible)
    database: str = "yugabyte"
    user: str = "yugabyte"
    password: str = ""

    # ── Smart Driver (psycopg2-yugabyte only) ─────────────────────────────────
    load_balance: bool = True
    topology_keys: str = ""               # e.g. "aws.us-east-1.*"
    yb_servers_refresh_interval: int = 300  # seconds; driver re-reads node list

    # ── Pool ──────────────────────────────────────────────────────────────────
    pool_min: int = 8      # connections pre-created at startup
    pool_max: int = 24     # hard ceiling (16 workers + 8 headroom)

    # ── TCP keepalive (OS-level; prevents silent idle-drop) ───────────────────
    connect_timeout: int = 30   # seconds for initial connect
    keepalives: int = 1         # enable keepalive probes
    keepalives_idle: int = 30   # start probing after 30 s idle
    keepalives_interval: int = 10   # re-probe every 10 s
    keepalives_count: int = 5   # give up after 5 consecutive failures → close

    # ── Retry / back-off ──────────────────────────────────────────────────────
    max_connect_retries: int = 5
    retry_base_delay: float = 0.5   # seconds before first retry
    retry_backoff: float = 2.0      # exponential multiplier

    # ── Statement guard ───────────────────────────────────────────────────────
    statement_timeout_ms: int = 600_000   # 10 min max per SQL statement

    # ── Pool health check ─────────────────────────────────────────────────────
    health_check_interval: int = 60  # seconds between background sweeps
    acquire_timeout: float = 30.0    # seconds a caller waits for a connection

    # ── ETL engine ────────────────────────────────────────────────────────────
    num_threads: int = 16
    batch_size: int = 5_000


# ─────────────────────────────────────────────────────────────────────────────
# Batch descriptor
# ─────────────────────────────────────────────────────────────────────────────

class OpType(Enum):
    INSERT = "insert"
    UPSERT = "upsert"
    UPDATE = "update"
    DELETE = "delete"


@dataclass
class Batch:
    """
    One unit of parallel work.

    conflict_cols  — primary / unique key column names used for:
                     UPSERT  → ON CONFLICT (conflict_cols)
                     UPDATE  → JOIN condition against temp table
                     DELETE  → JOIN / ANY condition

    update_cols    — columns written on conflict (UPSERT) or updated (UPDATE).
                     Defaults to all non-key columns when omitted.
    """
    op: OpType
    table: str
    records: List[Dict[str, Any]]
    conflict_cols: Optional[List[str]] = None
    update_cols: Optional[List[str]] = None


# ─────────────────────────────────────────────────────────────────────────────
# Robust Connection Pool
# ─────────────────────────────────────────────────────────────────────────────

class RobustPool:
    """
    Thread-safe connection pool for YugabyteDB.

    Design decisions
    ─────────────────
    • Internal queue (not psycopg2's built-in ThreadedConnectionPool) gives us
      full control over health checks and replacement logic.

    • acquire() validates every connection with a two-stage check before
      returning it to the caller:
        Stage 1 — conn.closed == 0  (Python object state, O(1))
        Stage 2 — non-blocking socket poll + SELECT 1  (network round-trip)
      If either fails the dead connection is silently discarded and a fresh
      one is created in its place.

    • A daemon thread runs _health_sweep() every `health_check_interval`
      seconds to proactively retire stale idle connections, keeping the pool
      warm even during long ETL pauses.

    • The DSN lists all 5 cluster nodes.  The Smart Driver distributes new
      connections round-robin and transparently retries other nodes on failure,
      so a single-node outage is invisible to application code.
    """

    def __init__(self, cfg: ClusterConfig):
        self._cfg = cfg
        self._q: queue.Queue[psycopg2.extensions.connection] = queue.Queue(
            maxsize=cfg.pool_max
        )
        self._lock = threading.Lock()
        self._active = 0
        self._closed = False

        self._stats: Dict[str, int] = {
            "created": 0, "replaced": 0, "create_failed": 0,
            "health_checks": 0, "health_failures": 0,
            "acquire_timeouts": 0,
        }
        self._stats_lock = threading.Lock()

        log.info(
            "Initialising pool: min=%d max=%d hosts=%s",
            cfg.pool_min, cfg.pool_max, cfg.hosts,
        )
        self._prefill()

        # Background health-check sweep
        t = threading.Thread(
            target=self._health_sweep, daemon=True, name="Pool-HealthCheck"
        )
        t.start()

    # ── DSN ───────────────────────────────────────────────────────────────────

    def _build_dsn(self) -> str:
        """
        Build a libpq key=value DSN.

        Multiple hosts tell the Smart Driver about all 5 nodes; it selects
        one per connection using its load-balancing policy and falls back to
        the others if the chosen host is unreachable.
        """
        c = self._cfg
        parts = [
            f"host={','.join(c.hosts)}",
            f"port={c.port}",
            f"dbname={c.database}",
            f"user={c.user}",
            f"password={c.password}",
            f"connect_timeout={c.connect_timeout}",
            # TCP keepalive parameters (map to setsockopt calls in libpq)
            f"keepalives={c.keepalives}",
            f"keepalives_idle={c.keepalives_idle}",
            f"keepalives_interval={c.keepalives_interval}",
            f"keepalives_count={c.keepalives_count}",
            # YugabyteDB Smart Driver extensions (ignored by stock psycopg2)
            "load_balance=true" if c.load_balance else "",
            f"yb_servers_refresh_interval={c.yb_servers_refresh_interval}",
        ]
        if c.topology_keys:
            parts.append(f"topology_keys={c.topology_keys}")
        return " ".join(p for p in parts if p)

    # ── Connection creation with retry ────────────────────────────────────────

    def _make_conn(self) -> psycopg2.extensions.connection:
        """
        Attempt to create a new connection.

        Retries up to max_connect_retries times with exponential back-off.
        Because the DSN includes all 5 nodes, each attempt may land on a
        different node, so transient per-node failures are self-healing.
        """
        cfg = self._cfg
        last_exc: Optional[Exception] = None

        for attempt in range(cfg.max_connect_retries):
            try:
                conn = psycopg2.connect(self._build_dsn())
                conn.autocommit = False

                # Session-level tuning applied once per connection
                with conn.cursor() as cur:
                    # Hard guard: no single statement runs forever
                    cur.execute(
                        f"SET statement_timeout = '{cfg.statement_timeout_ms}'"
                    )
                    # async commit: WAL write deferred to background → 3-5×
                    # throughput gain for ETL workloads.
                    # Trade-off: committed data may not survive a hard crash,
                    # but an ETL job can simply re-run from a checkpoint.
                    cur.execute("SET synchronous_commit = 'off'")

                    # YugabyteDB: increase write-restart attempt budget
                    cur.execute("SET ysql_max_write_restart_attempts = 20")

                conn.commit()

                with self._stats_lock:
                    self._stats["created"] += 1
                log.debug("New connection created (attempt %d/%d)", attempt + 1, cfg.max_connect_retries)
                return conn

            except psycopg2.OperationalError as exc:
                last_exc = exc
                with self._stats_lock:
                    self._stats["create_failed"] += 1
                wait = cfg.retry_base_delay * (cfg.retry_backoff ** attempt)
                log.warning(
                    "Connection attempt %d/%d failed: %s  — retry in %.1fs",
                    attempt + 1, cfg.max_connect_retries, exc, wait,
                )
                time.sleep(wait)

        raise psycopg2.OperationalError(
            f"All {cfg.max_connect_retries} connection attempts failed. "
            f"Last error: {last_exc}"
        )

    # ── Health check ──────────────────────────────────────────────────────────

    def _alive(self, conn: psycopg2.extensions.connection) -> bool:
        """
        Two-stage liveness check.

        Stage 1 – Python object flag (free):
            conn.closed != 0 means psycopg2 already knows it's dead.

        Stage 2 – Non-blocking socket poll + SELECT 1:
            A TCP RST or FIN from the server makes the socket readable even
            though no query was sent.  select() with timeout=0 catches this
            instantly.  We then issue SELECT 1 to confirm the connection is
            actually usable end-to-end.  Any exception → dead.
        """
        with self._stats_lock:
            self._stats["health_checks"] += 1

        try:
            if conn.closed:
                raise RuntimeError("conn.closed is set")

            # Non-blocking socket poll — detect TCP RST / server-side close
            try:
                fd = conn.fileno()
                r, _, _ = _select.select([fd], [], [], 0)
                # r is non-empty → socket has unexpected data or EOF.
                # We still do the real ping below to confirm.
            except Exception:
                pass  # fileno() fails on Windows in some edge cases; skip poll

            # Actual round-trip ping
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
            conn.rollback()   # leave connection in clean state
            return True

        except Exception as exc:
            with self._stats_lock:
                self._stats["health_failures"] += 1
            log.debug("Health check failed: %s", exc)
            return False

    def _close_quietly(self, conn: psycopg2.extensions.connection) -> None:
        try:
            if not conn.closed:
                conn.close()
        except Exception:
            pass

    # ── Pool pre-fill ─────────────────────────────────────────────────────────

    def _prefill(self) -> None:
        ok = 0
        for _ in range(self._cfg.pool_min):
            try:
                self._q.put_nowait(self._make_conn())
                ok += 1
            except Exception as exc:
                log.warning("Pre-fill slot failed: %s", exc)
        if ok == 0:
            raise RuntimeError(
                "Could not establish ANY connection to the YugabyteDB cluster. "
                "Check hosts, port, credentials, and network."
            )
        log.info("Pool ready: %d/%d connections pre-created", ok, self._cfg.pool_min)

    # ── Public API ────────────────────────────────────────────────────────────

    @contextmanager
    def acquire(self, timeout: Optional[float] = None):
        """
        Context manager — yields a *verified-live* connection.

        Acquire flow
        ─────────────
        1. Try to pop from the queue (blocks up to 2 s per attempt).
        2. Health-check the popped connection.
           a. Alive  → break; hand to caller.
           b. Dead   → close it, create a fresh replacement, break.
        3. If queue is empty and active < pool_max, create on-demand.
        4. Loop until a live connection is obtained or `timeout` expires.

        Return flow (finally block, always runs)
        ──────────────────────────────────────────
        • Rolls back any uncommitted transaction (cleans slate for next user).
        • Returns connection to queue if pool has room and conn is still alive.
        • Otherwise closes it gracefully.

        Usage::
            with pool.acquire() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1")
                conn.commit()
        """
        if self._closed:
            raise RuntimeError("Connection pool has been shut down")

        deadline = time.monotonic() + (timeout or self._cfg.acquire_timeout)
        conn: Optional[psycopg2.extensions.connection] = None

        # ── Acquisition loop ─────────────────────────────────────────────────
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                with self._stats_lock:
                    self._stats["acquire_timeouts"] += 1
                raise TimeoutError(
                    f"pool.acquire() timed out after "
                    f"{self._cfg.acquire_timeout}s "
                    f"(idle={self._q.qsize()}, active={self._active}, "
                    f"max={self._cfg.pool_max})"
                )

            # Try to get a connection from the idle queue
            try:
                conn = self._q.get(timeout=min(2.0, remaining))
            except queue.Empty:
                # Queue is empty — create a new connection if below the cap
                with self._lock:
                    if self._active < self._cfg.pool_max:
                        try:
                            conn = self._make_conn()
                            break   # fresh conn; skip health check
                        except Exception as exc:
                            log.warning("On-demand conn creation failed: %s", exc)
                # Still below cap but creation failed — loop and wait
                time.sleep(0.1)
                continue

            # Health-check the pooled connection
            if self._alive(conn):
                break   # good connection found

            # Dead connection — replace it
            log.info("Dead connection detected; creating replacement")
            self._close_quietly(conn)
            with self._stats_lock:
                self._stats["replaced"] += 1
            try:
                conn = self._make_conn()
                break   # replacement is fresh; no need to re-check
            except Exception as exc:
                log.warning("Replacement creation failed: %s. Will retry.", exc)
                conn = None
                time.sleep(0.5)

        # ── Yield to caller ──────────────────────────────────────────────────
        with self._lock:
            self._active += 1
        try:
            yield conn
            # Clean up any uncommitted work from the caller
            if conn and not conn.closed:
                try:
                    conn.rollback()
                except Exception:
                    pass
        except Exception:
            if conn and not conn.closed:
                try:
                    conn.rollback()
                except Exception:
                    pass
            raise
        finally:
            with self._lock:
                self._active = max(0, self._active - 1)

            if conn is not None:
                if not conn.closed and not self._closed:
                    try:
                        self._q.put_nowait(conn)
                        conn = None   # ownership transferred to queue
                    except queue.Full:
                        pass          # pool full; fall through to close
                if conn is not None:
                    self._close_quietly(conn)

    # ── Background health sweep ───────────────────────────────────────────────

    def _health_sweep(self) -> None:
        """
        Daemon thread: periodically validates every idle connection.

        Drains the queue, pings each connection, then puts live ones back and
        replaces dead ones.  This prevents a long idle gap (e.g., between ETL
        phases) from leaving the pool full of stale connections.
        """
        log.info(
            "Health-sweep thread started (interval=%ds)",
            self._cfg.health_check_interval,
        )
        while not self._closed:
            time.sleep(self._cfg.health_check_interval)
            if self._closed:
                break

            # Drain idle connections into a local list
            batch: List[psycopg2.extensions.connection] = []
            while True:
                try:
                    batch.append(self._q.get_nowait())
                except queue.Empty:
                    break

            checked = replaced = discarded = 0
            for c in batch:
                checked += 1
                if self._alive(c):
                    try:
                        self._q.put_nowait(c)
                    except queue.Full:
                        self._close_quietly(c)
                        discarded += 1
                else:
                    self._close_quietly(c)
                    with self._stats_lock:
                        self._stats["replaced"] += 1
                    try:
                        nc = self._make_conn()
                        self._q.put_nowait(nc)
                        replaced += 1
                    except Exception as exc:
                        log.warning("Sweep replacement failed: %s", exc)

            log.info(
                "Health sweep: checked=%d  replaced=%d  discarded=%d  pool_idle=%d",
                checked, replaced, discarded, self._q.qsize(),
            )

    # ── Pool stats / lifecycle ────────────────────────────────────────────────

    def stats(self) -> Dict[str, int]:
        with self._stats_lock:
            s = dict(self._stats)
        s["pool_idle"] = self._q.qsize()
        s["pool_active"] = self._active
        return s

    def close(self) -> None:
        """Drain the idle queue and close every connection gracefully."""
        self._closed = True
        n = 0
        while True:
            try:
                self._close_quietly(self._q.get_nowait())
                n += 1
            except queue.Empty:
                break
        log.info("Pool closed — %d idle connections released", n)

    def __enter__(self) -> "RobustPool":
        return self

    def __exit__(self, *_) -> None:
        self.close()


# ─────────────────────────────────────────────────────────────────────────────
# Retry wrapper (serialisation / deadlock errors)
# ─────────────────────────────────────────────────────────────────────────────

_TRANSIENT = (
    psycopg2.errors.SerializationFailure,
    psycopg2.errors.DeadlockDetected,
    psycopg2.errors.LockNotAvailable,
)
_MAX_OP_RETRIES = 5


def _with_retry(fn: Callable[[], Any]) -> Any:
    """
    Call fn() and retry on YugabyteDB transient errors.

    YugabyteDB uses optimistic concurrency; under high parallelism a
    transaction may be restarted by the server.  The correct response is to
    re-execute the entire transaction from scratch, which is exactly what
    happens here because fn() always acquires a fresh connection from the pool.
    """
    for attempt in range(_MAX_OP_RETRIES):
        try:
            return fn()
        except _TRANSIENT as exc:
            if attempt == _MAX_OP_RETRIES - 1:
                raise
            wait = 0.05 * (2 ** attempt)
            log.warning(
                "Transient error (attempt %d/%d): %s — retry in %.2fs",
                attempt + 1, _MAX_OP_RETRIES, type(exc).__name__, wait,
            )
            time.sleep(wait)
        except psycopg2.OperationalError as exc:
            if attempt == _MAX_OP_RETRIES - 1:
                raise
            wait = 0.5 * (2 ** attempt)
            log.warning(
                "OperationalError (attempt %d/%d): %s — retry in %.2fs",
                attempt + 1, _MAX_OP_RETRIES, exc, wait,
            )
            time.sleep(wait)


# ─────────────────────────────────────────────────────────────────────────────
# Bulk operation primitives
# ─────────────────────────────────────────────────────────────────────────────

def _pg_escape(v: Any) -> str:
    """
    Escape a Python value for PostgreSQL COPY TEXT format.

    Rules (per PostgreSQL docs):
        \\N          → NULL literal (must come before backslash escaping)
        \\           → \\\\
        \\t (tab)    → \\t
        \\n (LF)     → \\n
        \\r (CR)     → \\r
    """
    if v is None:
        return r"\N"
    s = str(v)
    s = s.replace("\\", "\\\\")
    s = s.replace("\t", "\\t")
    s = s.replace("\n", "\\n")
    s = s.replace("\r", "\\r")
    return s


def _build_copy_buffer(records: List[Dict], cols: List[str]) -> io.StringIO:
    """
    Serialise records into a tab-delimited TEXT-format COPY buffer.
    Handles NULL, special characters, and Unicode correctly.
    """
    lines: List[str] = []
    for r in records:
        lines.append("\t".join(_pg_escape(r.get(c)) for c in cols))
    buf = io.StringIO("\n".join(lines) + "\n")
    return buf


def _tmp_name() -> str:
    """Unique temp-table name scoped to this thread + microsecond timestamp."""
    return f"_yb_tmp_{threading.get_ident()}_{int(time.monotonic() * 1_000_000)}"


class BulkOps:
    """
    Low-level bulk operation implementations.
    All methods operate on a pre-acquired connection and cursor.
    """

    # ── INSERT via COPY (fastest path) ────────────────────────────────────────

    @staticmethod
    def copy_insert(
        cur: psycopg2.extensions.cursor,
        table: str,
        records: List[Dict],
        cols: List[str],
    ) -> int:
        """
        Bulk INSERT using the PostgreSQL COPY protocol.

        COPY FROM STDIN is the fastest possible ingestion path — data is
        streamed directly to the server with minimal per-row overhead.  No
        individual row round-trips, no expression parsing per row.
        """
        buf = _build_copy_buffer(records, cols)
        col_sql = ", ".join(f'"{c}"' for c in cols)
        cur.copy_expert(
            f'COPY {table} ({col_sql}) FROM STDIN '
            f"WITH (FORMAT text, DELIMITER E'\\t', NULL '\\\\N')",
            buf,
        )
        # COPY does not set rowcount reliably on all versions; return len
        return len(records)

    # ── UPSERT via execute_values ──────────────────────────────────────────────

    @staticmethod
    def execute_values_upsert(
        cur: psycopg2.extensions.cursor,
        table: str,
        records: List[Dict],
        cols: List[str],
        conflict_cols: List[str],
        update_cols: List[str],
        page_size: int = 2_000,
    ) -> int:
        """
        INSERT … ON CONFLICT (key) DO UPDATE SET … via execute_values.

        execute_values sends multiple rows in a single round-trip using the
        VALUES list, which is significantly faster than individual INSERTs
        while still supporting conflict resolution.
        """
        col_names  = ", ".join(f'"{c}"' for c in cols)
        conflict   = ", ".join(f'"{c}"' for c in conflict_cols)
        updates    = ", ".join(f'"{c}" = EXCLUDED."{c}"' for c in update_cols)
        sql = (
            f'INSERT INTO {table} ({col_names}) VALUES %s '
            f'ON CONFLICT ({conflict}) DO UPDATE SET {updates}'
        )
        values = [tuple(r.get(c) for c in cols) for r in records]
        psycopg2.extras.execute_values(cur, sql, values, page_size=page_size)
        return len(records)

    # ── UPDATE via temp table ─────────────────────────────────────────────────

    @staticmethod
    def temp_table_update(
        conn: psycopg2.extensions.connection,
        cur: psycopg2.extensions.cursor,
        table: str,
        records: List[Dict],
        key_cols: List[str],
        update_cols: List[str],
    ) -> int:
        """
        Bulk UPDATE using COPY → temp table → UPDATE … FROM.

        Why temp table instead of individual UPDATEs?
        • N individual UPDATEs → N round-trips, N lock acquisitions.
        • Temp table approach → 1 COPY + 1 UPDATE = 2 round-trips regardless
          of N, with the server doing a hash or merge join internally.
        """
        all_cols = list(dict.fromkeys(key_cols + update_cols))
        col_defs  = ", ".join(f'"{c}" TEXT' for c in all_cols)
        tmp = _tmp_name()

        # Temp table scoped to this transaction (ON COMMIT DROP)
        cur.execute(
            f'CREATE TEMP TABLE "{tmp}" ({col_defs}) ON COMMIT DROP'
        )
        cur.copy_expert(
            f'COPY "{tmp}" ({", ".join(f\'"{c}"\' for c in all_cols)}) '
            f"FROM STDIN WITH (FORMAT text, DELIMITER E'\\t', NULL '\\\\N')",
            _build_copy_buffer(records, all_cols),
        )

        join    = " AND ".join(
            f'{table}."{c}" = t."{c}"' for c in key_cols
        )
        set_clause = ", ".join(f'"{c}" = t."{c}"' for c in update_cols)
        cur.execute(
            f'UPDATE {table} SET {set_clause} FROM "{tmp}" AS t WHERE {join}'
        )
        return cur.rowcount

    # ── DELETE via temp table (composite keys) or ANY (single key) ─────────

    @staticmethod
    def temp_table_delete(
        conn: psycopg2.extensions.connection,
        cur: psycopg2.extensions.cursor,
        table: str,
        records: List[Dict],
        key_cols: List[str],
    ) -> int:
        """
        Bulk DELETE.

        Single key column  → DELETE WHERE col = ANY(%s::type[])
          — avoids temp table overhead for simple cases.
        Composite key      → COPY keys to temp table + DELETE … USING temp.
        """
        if len(key_cols) == 1:
            col = key_cols[0]
            vals = [r.get(col) for r in records]
            cur.execute(f'DELETE FROM {table} WHERE "{col}" = ANY(%s)', (vals,))
            return cur.rowcount

        col_defs = ", ".join(f'"{c}" TEXT' for c in key_cols)
        tmp = _tmp_name()
        cur.execute(
            f'CREATE TEMP TABLE "{tmp}" ({col_defs}) ON COMMIT DROP'
        )
        cur.copy_expert(
            f'COPY "{tmp}" ({", ".join(f\'"{c}"\' for c in key_cols)}) '
            f"FROM STDIN WITH (FORMAT text, DELIMITER E'\\t', NULL '\\\\N')",
            _build_copy_buffer(records, key_cols),
        )
        join = " AND ".join(
            f'{table}."{c}" = t."{c}"' for c in key_cols
        )
        cur.execute(
            f'DELETE FROM {table} USING "{tmp}" AS t WHERE {join}'
        )
        return cur.rowcount


# ─────────────────────────────────────────────────────────────────────────────
# ETL result accumulator (thread-safe)
# ─────────────────────────────────────────────────────────────────────────────

class ETLResult:
    """Thread-safe counter bag; every worker thread writes into it."""

    def __init__(self):
        self._lock   = threading.Lock()
        self.inserted  = 0
        self.upserted  = 0
        self.updated   = 0
        self.deleted   = 0
        self.errors:        List[Exception]    = []
        self.failed_metas:  List[Dict[str, Any]] = []
        self._start  = time.monotonic()
        self._end:   Optional[float] = None

    def _inc(self, attr: str, n: int) -> None:
        with self._lock:
            setattr(self, attr, getattr(self, attr) + n)

    def add_inserted(self, n: int):  self._inc("inserted", n)
    def add_upserted(self, n: int):  self._inc("upserted", n)
    def add_updated(self, n: int):   self._inc("updated",  n)
    def add_deleted(self, n: int):   self._inc("deleted",  n)

    def add_error(self, exc: Exception, meta: Optional[Dict] = None) -> None:
        with self._lock:
            self.errors.append(exc)
            if meta:
                self.failed_metas.append(meta)

    def finish(self) -> None:
        self._end = time.monotonic()

    @property
    def total(self) -> int:
        return self.inserted + self.upserted + self.updated + self.deleted

    @property
    def elapsed(self) -> float:
        return (self._end or time.monotonic()) - self._start

    @property
    def rps(self) -> float:
        return self.total / self.elapsed if self.elapsed > 0 else 0.0

    def __str__(self) -> str:
        bar = "─" * 52
        return (
            f"\n{bar}\n"
            f"  ETL COMPLETE\n"
            f"{bar}\n"
            f"  Total records : {self.total:>14,}\n"
            f"  Elapsed       : {self.elapsed:>13.1f}s\n"
            f"  Throughput    : {self.rps:>11,.0f} rec/s\n"
            f"{bar}\n"
            f"  INSERT        : {self.inserted:>14,}\n"
            f"  UPSERT        : {self.upserted:>14,}\n"
            f"  UPDATE        : {self.updated:>14,}\n"
            f"  DELETE        : {self.deleted:>14,}\n"
            f"  Errors        : {len(self.errors):>14,}\n"
            f"{bar}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Parallel ETL Engine
# ─────────────────────────────────────────────────────────────────────────────

def _chunk(lst: List, size: int) -> Generator:
    """Split a list into consecutive sub-lists of at most `size` items."""
    for i in range(0, len(lst), size):
        yield lst[i: i + size]


class YBETLEngine:
    """
    Parallel ETL engine — 16 worker threads, full INSERT/UPSERT/UPDATE/DELETE.

    Architecture
    ─────────────
    • ThreadPoolExecutor(max_workers=16) dispatches Batch objects to workers.
    • Each worker independently calls pool.acquire(), runs its bulk operation,
      commits, and returns the connection.  No connection is shared between
      threads.
    • run()        — convenience: takes a flat record list, auto-chunks, runs.
    • run_batches()— fine-grained: accepts pre-built Batch objects, supports
                     mixed operations in a single parallel call.
    """

    def __init__(
        self,
        pool: RobustPool,
        num_threads: int = 16,
        batch_size:  int = 5_000,
    ):
        self.pool        = pool
        self.num_threads = num_threads
        self.batch_size  = batch_size
        self._log        = logging.getLogger("YBETLEngine")

    # ── Convenience entry-point ───────────────────────────────────────────────

    def run(
        self,
        records:       List[Dict[str, Any]],
        table:         str,
        op:            OpType,
        conflict_cols: Optional[List[str]] = None,
        update_cols:   Optional[List[str]] = None,
        progress_every: int = 500_000,
    ) -> ETLResult:
        """
        Auto-chunk `records` into batches of `batch_size` and run in parallel.

        Example (250 M record UPSERT)::

            result = engine.run(
                records       = all_records,
                table         = "public.final_table",
                op            = OpType.UPSERT,
                conflict_cols = ["id"],
                update_cols   = ["name", "value", "updated_at"],
            )
            print(result)
        """
        self._log.info(
            "run(): op=%s  table=%s  records=%s  threads=%d  batch_size=%s",
            op.value, table, f"{len(records):,}", self.num_threads,
            f"{self.batch_size:,}",
        )
        batches = [
            Batch(
                op=op, table=table,
                records=list(chunk),
                conflict_cols=conflict_cols,
                update_cols=update_cols,
            )
            for chunk in _chunk(records, self.batch_size)
        ]
        self._log.info("Split into %d batches", len(batches))
        return self.run_batches(batches, progress_every=progress_every)

    # ── Core parallel executor ────────────────────────────────────────────────

    def run_batches(
        self,
        batches:        List[Batch],
        progress_every: int = 500_000,
    ) -> ETLResult:
        """
        Execute a list of Batch objects in parallel.

        Mixed operations are fully supported — you can pass INSERT batches for
        one table and DELETE batches for another in the same call.  Workers
        will process them concurrently up to num_threads at a time.
        """
        result      = ETLResult()
        total       = len(batches)
        done        = [0]
        done_lock   = threading.Lock()
        next_report = [progress_every]

        self._log.info(
            "run_batches(): %d batches × %d threads", total, self.num_threads
        )

        with ThreadPoolExecutor(
            max_workers=self.num_threads,
            thread_name_prefix="YB-Worker",
        ) as ex:

            future_meta: Dict[Future, Dict[str, Any]] = {}
            for i, b in enumerate(batches):
                f = ex.submit(self._execute_batch, b, i, result)
                future_meta[f] = {
                    "batch_idx": i, "table": b.table,
                    "op": b.op.value, "count": len(b.records),
                }

            for f in as_completed(future_meta):
                meta = future_meta[f]
                try:
                    f.result()
                    with done_lock:
                        done[0] += 1
                        if result.total >= next_report[0]:
                            next_report[0] += progress_every
                            self._log.info(
                                "Progress: %d/%d batches | %s records | %.0f rec/s",
                                done[0], total,
                                f"{result.total:,}", result.rps,
                            )
                except Exception as exc:
                    self._log.error(
                        "Batch %d FAILED  table=%s  op=%s: %s",
                        meta["batch_idx"], meta["table"], meta["op"], exc,
                        exc_info=True,
                    )
                    result.add_error(exc, meta)

        result.finish()
        self._log.info("%s", result)
        return result

    # ── Worker ────────────────────────────────────────────────────────────────

    def _execute_batch(
        self,
        batch:  Batch,
        idx:    int,
        result: ETLResult,
    ) -> None:
        """
        Run one Batch inside a worker thread.

        Wrapped in _with_retry so serialisation failures automatically retry
        the entire batch transaction.  The pool's acquire() provides a fresh,
        health-checked connection for each attempt.
        """
        if not batch.records:
            return

        cols          = list(batch.records[0].keys())
        conflict_cols = batch.conflict_cols or []
        update_cols   = batch.update_cols or [c for c in cols if c not in conflict_cols]

        def _work() -> None:
            with self.pool.acquire() as conn:
                with conn.cursor() as cur:

                    if batch.op == OpType.INSERT:
                        n = BulkOps.copy_insert(cur, batch.table, batch.records, cols)
                        conn.commit()
                        result.add_inserted(n)

                    elif batch.op == OpType.UPSERT:
                        n = BulkOps.execute_values_upsert(
                            cur, batch.table, batch.records, cols,
                            conflict_cols, update_cols,
                            page_size=self.batch_size,
                        )
                        conn.commit()
                        result.add_upserted(n)

                    elif batch.op == OpType.UPDATE:
                        n = BulkOps.temp_table_update(
                            conn, cur, batch.table, batch.records,
                            conflict_cols, update_cols,
                        )
                        conn.commit()
                        result.add_updated(n)

                    elif batch.op == OpType.DELETE:
                        n = BulkOps.temp_table_delete(
                            conn, cur, batch.table, batch.records, conflict_cols,
                        )
                        conn.commit()
                        result.add_deleted(n)

        _with_retry(_work)


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

def build_engine(cfg: ClusterConfig) -> Tuple[RobustPool, YBETLEngine]:
    """
    Create and return (pool, engine) from a ClusterConfig.

    Always use this inside a try/finally or a `with` block::

        pool, engine = build_engine(cfg)
        try:
            result = engine.run(records, "my_table", OpType.UPSERT, ...)
        finally:
            pool.close()
    """
    pool   = RobustPool(cfg)
    engine = YBETLEngine(
        pool,
        num_threads=cfg.num_threads,
        batch_size=cfg.batch_size,
    )
    return pool, engine


# ─────────────────────────────────────────────────────────────────────────────
# Demo / smoke test  (replace sample data with your 250 M record source)
# ─────────────────────────────────────────────────────────────────────────────

# ── DDL reference (run once against your cluster) ────────────────────────────
_DDL = """
-- Target table (5-node RF-3 cluster; hash-partitioned on id)
CREATE TABLE IF NOT EXISTS public.final_table (
    id          BIGINT       PRIMARY KEY,
    name        TEXT         NOT NULL,
    value       NUMERIC(18,4),
    category    TEXT,
    updated_at  TIMESTAMPTZ  DEFAULT NOW()
)  SPLIT INTO 16 TABLETS;     -- 16 tablets spreads across 5 nodes evenly

CREATE TABLE IF NOT EXISTS public.staging (
    id    BIGINT  PRIMARY KEY,
    name  TEXT,
    value NUMERIC(18,4)
)  SPLIT INTO 8 TABLETS;
"""


def demo() -> None:
    """
    End-to-end demonstration of all four operation modes.

    Swap the `_sample()` calls for your real data source (file, upstream DB,
    S3, etc.).  The engine itself is source-agnostic; it just needs a list of
    dicts matching the target table's column names.
    """

    def _sample(n: int, offset: int = 0) -> List[Dict]:
        return [
            {
                "id":         offset + i,
                "name":       f"record_{offset + i}",
                "value":      round((offset + i) * 1.23456, 4),
                "category":   "A" if i % 3 == 0 else "B",
                "updated_at": "NOW()",
            }
            for i in range(n)
        ]

    # ── Cluster configuration ─────────────────────────────────────────────────
    cfg = ClusterConfig(
        hosts=[
            "yb-node-1.example.com",
            "yb-node-2.example.com",
            "yb-node-3.example.com",
            "yb-node-4.example.com",
            "yb-node-5.example.com",
        ],
        port=5433,
        database="etl_db",
        user="etl_user",
        password="s3cr3t",

        # Smart Driver load-balancing; adjust to your cloud/region
        load_balance=True,
        topology_keys="aws.us-east-1.*",

        # Pool: 8 warm + up to 24 total (covers 16 workers + headroom)
        pool_min=8,
        pool_max=24,

        # TCP keepalive — critical for long-running ETL sessions
        keepalives=1,
        keepalives_idle=30,
        keepalives_interval=10,
        keepalives_count=5,

        # ETL
        num_threads=16,
        batch_size=5_000,
    )

    with RobustPool(cfg) as pool:
        engine = YBETLEngine(pool, num_threads=cfg.num_threads,
                             batch_size=cfg.batch_size)

        # ── 1. Pure INSERT via COPY (fastest: no conflict handling needed) ────
        log.info("=== Demo 1: Bulk INSERT (COPY) ===")
        r = engine.run(
            records=_sample(100_000, offset=0),
            table="public.staging",
            op=OpType.INSERT,
        )
        print(r)

        # ── 2. UPSERT — most common ETL pattern ───────────────────────────────
        log.info("=== Demo 2: Bulk UPSERT ===")
        r = engine.run(
            records=_sample(200_000, offset=0),
            table="public.final_table",
            op=OpType.UPSERT,
            conflict_cols=["id"],
            update_cols=["name", "value", "category", "updated_at"],
        )
        print(r)

        # ── 3. Selective UPDATE (only the 'value' column changes) ─────────────
        log.info("=== Demo 3: Bulk UPDATE ===")
        update_records = [
            {"id": i, "value": round(i * 9.99, 4)}
            for i in range(0, 50_000)
        ]
        r = engine.run(
            records=update_records,
            table="public.final_table",
            op=OpType.UPDATE,
            conflict_cols=["id"],
            update_cols=["value"],
        )
        print(r)

        # ── 4. Bulk DELETE ─────────────────────────────────────────────────────
        log.info("=== Demo 4: Bulk DELETE ===")
        r = engine.run(
            records=[{"id": i} for i in range(90_000, 100_000)],
            table="public.final_table",
            op=OpType.DELETE,
            conflict_cols=["id"],
        )
        print(r)

        # ── 5. Mixed operations — different tables, same parallel run ─────────
        log.info("=== Demo 5: Mixed parallel run ===")
        mixed_batches: List[Batch] = []

        # 4 UPSERT batches into final_table
        for chunk in _chunk(_sample(20_000, offset=500_000), cfg.batch_size):
            mixed_batches.append(Batch(
                op=OpType.UPSERT,
                table="public.final_table",
                records=list(chunk),
                conflict_cols=["id"],
                update_cols=["name", "value", "updated_at"],
            ))

        # 2 INSERT batches into staging
        for chunk in _chunk(_sample(10_000, offset=600_000), cfg.batch_size):
            mixed_batches.append(Batch(
                op=OpType.INSERT,
                table="public.staging",
                records=list(chunk),
            ))

        # 1 DELETE batch
        mixed_batches.append(Batch(
            op=OpType.DELETE,
            table="public.final_table",
            records=[{"id": i} for i in range(500_000, 500_200)],
            conflict_cols=["id"],
        ))

        r = engine.run_batches(mixed_batches)
        print(r)

        # ── Pool diagnostics ───────────────────────────────────────────────────
        log.info("Pool stats: %s", pool.stats())


if __name__ == "__main__":
    demo()
