"""
config.py – YugabyteDB ETL Pipeline Configuration
===================================================
All connection, pool, keepalive, session, and retry settings in one place.
The Smart Driver uses `load_balance=true` + multiple hosts to distribute
connections uniformly across all 5 nodes and fail-over automatically.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class DBConfig:
    """
    Full connection configuration for a YugabyteDB cluster.

    Supply every node address in `hosts`.  The YugabyteDB Smart Driver
    (yb_psycopg2) contacts all of them for load-balancing; standard
    psycopg2 ≥ 2.9 tries them in order for simple failover.

    RF-3 cluster: any surviving 2-of-5 nodes can serve reads/writes,
    so node-level TCP failures are handled transparently at the driver
    or pool level without requiring application-level intervention.
    """

    # ── Cluster ────────────────────────────────────────────────────────────
    hosts: List[str] = field(
        default_factory=lambda: [
            "yb-node1.example.com",
            "yb-node2.example.com",
            "yb-node3.example.com",
            "yb-node4.example.com",
            "yb-node5.example.com",
        ]
    )
    port: int = 5433          # YSQL default; change to 5432 if using PostgreSQL compat port
    database: str = "yugabyte"
    user: str = "yugabyte"
    password: str = ""

    # ── YugabyteDB Smart Driver ─────────────────────────────────────────────
    # load_balance=true  → uniform connection distribution across live nodes
    # topology_keys      → prefer nodes in certain zones, e.g.
    #                       "cloud1.region1.zone1:1,cloud1.region1.zone2:2"
    load_balance: bool = True
    topology_keys: Optional[str] = None

    # ── Connection Pool ─────────────────────────────────────────────────────
    pool_min: int = 16          # pre-warmed connections (= num_workers is ideal)
    pool_max: int = 24          # hard cap; must be ≥ pool_min
    acquire_timeout: float = 30.0    # seconds to wait before raising TimeoutError
    connect_timeout: int = 10         # TCP-level connect timeout per attempt

    # ── TCP Keep-alive ──────────────────────────────────────────────────────
    # Without keepalives, NAT devices / load-balancers silently drop idle
    # connections after minutes.  These OS-level probes keep the socket alive.
    keepalives: int = 1               # 1 = enable
    keepalives_idle: int = 60         # seconds of idle before first probe
    keepalives_interval: int = 10     # seconds between probes
    keepalives_count: int = 5         # probes before giving up and closing

    # ── Session Parameters ──────────────────────────────────────────────────
    # Applied immediately after connecting via 'options' in the DSN string.
    statement_timeout_ms: int = 0              # 0 = unlimited (good for ETL)
    idle_in_txn_timeout_ms: int = 300_000      # 5 min – kill stuck transactions

    # ── Retry / Reconnect ────────────────────────────────────────────────────
    reconnect_retries: int = 5
    reconnect_backoff_base: float = 0.5   # seconds; doubles each retry (max 30s)

    # ── Health Check ────────────────────────────────────────────────────────
    # Connections idle longer than this threshold get a SELECT-1 ping on
    # the next acquire() call.  Below the threshold, only the closed/status
    # flags are checked (no network round-trip).
    ping_idle_threshold_sec: float = 30.0

    # ── Background Sweep ────────────────────────────────────────────────────
    health_sweep_interval_sec: int = 60   # how often the daemon sweeper runs

    # ── Misc ────────────────────────────────────────────────────────────────
    application_name: str = "yb_etl_pipeline"

    # ────────────────────────────────────────────────────────────────────────

    def dsn(self) -> dict:
        """
        Build the keyword-argument dict for psycopg2.connect() / yb_psycopg2.connect().

        Multi-host string
        ─────────────────
        psycopg2 ≥ 2.9 accepts 'host=h1,h2,h3' and tries each host in order.
        yb_psycopg2 (Smart Driver) distributes connections across all listed
        hosts using its internal topology cache, re-routing automatically when
        a node becomes unavailable.

        Smart-driver extensions (load_balance, topology_keys) are only added
        when the Smart Driver is installed; the pool strips them for plain
        psycopg2 to avoid "invalid connection option" errors.
        """
        dsn: dict = {
            "host":              ",".join(self.hosts),
            "port":              self.port,
            "dbname":            self.database,
            "user":              self.user,
            "password":          self.password,
            "application_name":  self.application_name,
            "connect_timeout":   self.connect_timeout,
            # TCP keepalive – prevents silent connection drops on idle sockets
            "keepalives":          self.keepalives,
            "keepalives_idle":     self.keepalives_idle,
            "keepalives_interval": self.keepalives_interval,
            "keepalives_count":    self.keepalives_count,
            # Session-level PG settings applied at connect time
            "options": (
                f"-c statement_timeout={self.statement_timeout_ms} "
                f"-c idle_in_transaction_session_timeout={self.idle_in_txn_timeout_ms}"
            ),
        }
        # Smart Driver parameters – stripped by the pool for plain psycopg2
        if self.load_balance:
            dsn["load_balance"] = "true"
        if self.topology_keys:
            dsn["topology_keys"] = self.topology_keys
        return dsn
