"""
main.py – YugabyteDB ETL Pipeline Entry Point
==============================================

Demonstrates all wiring:
  • 5-node cluster with Smart Driver load-balancing + auto-failover
  • Resilient connection pool (dead-connection detection and replacement)
  • 16-thread parallel bulk load
  • UPSERT pipeline  (most common for 250 M record ETL)
  • MIXED  pipeline  (when source rows carry I/U/D/X operation tags)
  • Server-side cursor – 250 M rows never buffered in Python memory

Replace the NODES list, DB credentials, table names, column lists, and
transform_fn with your own values.
"""

from __future__ import annotations

import logging
import signal
import sys
from typing import Any, List, Tuple

from config         import DBConfig
from connection_pool import ResilientYBPool
from bulk_ops       import Op
from etl_pipeline   import YBETLPipeline

# ════════════════════════════════════════════════════════════════════════════
#  Logging
# ════════════════════════════════════════════════════════════════════════════

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)-8s] %(name)s – %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("etl_run.log", mode="a"),
    ],
)
log = logging.getLogger("main")


# ════════════════════════════════════════════════════════════════════════════
#  Cluster configuration
# ════════════════════════════════════════════════════════════════════════════

# All 5 node addresses of your RF-3 cluster.
# The Smart Driver (yb_psycopg2) distributes new connections uniformly
# across these nodes and automatically avoids any that go down.
# Standard psycopg2 (≥ 2.9) tries them left-to-right for basic failover.
NODES = [
    "yb-node1.prod.internal",
    "yb-node2.prod.internal",
    "yb-node3.prod.internal",
    "yb-node4.prod.internal",
    "yb-node5.prod.internal",
]

# ── Source database (read-only ETL queries) ──────────────────────────────────
SOURCE_CFG = DBConfig(
    hosts                   = NODES,
    database                = "source_db",
    user                    = "etl_reader",
    password                = "change_me",
    pool_min                = 2,   # source only needs a few connections
    pool_max                = 4,   # one server-side cursor per connection
    connect_timeout         = 10,
    keepalives_idle         = 60,
    statement_timeout_ms    = 0,   # long-running SELECT across 250 M rows
    reconnect_retries       = 5,
    application_name        = "yb_etl_source",
)

# ── Target database (bulk write) ──────────────────────────────────────────────
TARGET_CFG = DBConfig(
    hosts                   = NODES,
    database                = "target_db",
    user                    = "etl_writer",
    password                = "change_me",
    pool_min                = 16,  # match num_workers – all slots pre-warmed
    pool_max                = 24,  # buffer above num_workers for pool churn
    connect_timeout         = 10,
    keepalives_idle         = 60,
    statement_timeout_ms    = 0,
    idle_in_txn_timeout_ms  = 300_000,
    reconnect_retries       = 5,
    ping_idle_threshold_sec = 30.0,
    health_sweep_interval_sec = 60,
    application_name        = "yb_etl_target",
)


# ════════════════════════════════════════════════════════════════════════════
#  Transformation functions  ← replace with your business logic
# ════════════════════════════════════════════════════════════════════════════

def transform_upsert(batch: List[tuple]) -> List[tuple]:
    """
    Example: read (id, raw_a, raw_b, category_code) from source,
    compute derived metrics, return rows ready for the final table.

    Source row:   (id INT, raw_a NUMERIC, raw_b NUMERIC, cat TEXT)
    Target row:   (id INT, metric_1 NUMERIC, metric_2 NUMERIC, category TEXT, flag BOOL)
    """
    out: List[tuple] = []
    for row in batch:
        rec_id, raw_a, raw_b, cat_code = row[0], row[1], row[2], row[3]

        # ── your complex calculations here ─────────────────────────────────
        metric_1 = round(float(raw_a or 0) * 1.15 + float(raw_b or 0) * 0.85, 6)
        metric_2 = round((float(raw_a or 0) ** 0.5) if (raw_a or 0) >= 0 else 0.0, 6)
        category = str(cat_code).upper() if cat_code else "UNKNOWN"
        flag     = metric_1 > 1_000.0
        # ───────────────────────────────────────────────────────────────────

        out.append((rec_id, metric_1, metric_2, category, flag))
    return out


def transform_mixed(batch: List[tuple]) -> List[Tuple[Op, tuple]]:
    """
    Example: source table has an `op_flag` column that drives which DML
    operation to perform on each row in the target.

    Source row: (id, op_flag CHAR(1), value NUMERIC, …)
      op_flag = 'I' → INSERT,  'U' → UPDATE,  'D' → DELETE,  'X' → UPSERT
    """
    out: List[Tuple[Op, tuple]] = []
    op_map = {"I": Op.INSERT, "U": Op.UPDATE, "D": Op.DELETE, "X": Op.UPSERT}

    for row in batch:
        rec_id, op_flag, value = row[0], row[1], row[2]
        op = op_map.get(str(op_flag).upper(), Op.UPSERT)

        if op == Op.DELETE:
            out.append((Op.DELETE, (rec_id,)))
        else:
            computed = round(float(value or 0) * 1.15, 6)
            out.append((op, (rec_id, computed)))

    return out


# ════════════════════════════════════════════════════════════════════════════
#  Main
# ════════════════════════════════════════════════════════════════════════════

def main() -> int:
    log.info("=== YugabyteDB ETL Pipeline starting ===")

    # ── Build connection pools ─────────────────────────────────────────────
    log.info("Creating source pool…")
    source_pool = ResilientYBPool(SOURCE_CFG)

    log.info("Creating target pool…")
    target_pool = ResilientYBPool(TARGET_CFG)

    pipeline = YBETLPipeline(
        source_pool  = source_pool,
        target_pool  = target_pool,
        num_workers  = 16,        # 16 parallel loader threads
        batch_size   = 10_000,    # rows per COPY / execute_values call
        queue_cap    = 64,        # max in-flight batches  (≈ 640 K rows)
        max_retries  = 3,         # per-batch retry attempts
        log_interval = 200,       # progress log every N batches
    )

    # ── Graceful SIGINT / SIGTERM handling ────────────────────────────────
    def _on_signal(sig, _frame):
        log.warning("Signal %s received – requesting graceful stop…", sig)
        pipeline.stop()

    signal.signal(signal.SIGINT,  _on_signal)
    signal.signal(signal.SIGTERM, _on_signal)

    # ────────────────────────────────────────────────────────────────────────
    # Choose which pipeline variant to run.
    # Uncomment / adapt the one that matches your ETL pattern.
    # ────────────────────────────────────────────────────────────────────────

    try:
        # ── Option 1: UPSERT (most common for 250 M record load) ──────────
        stats = pipeline.run_upsert(
            source_query  = (
                "SELECT id, raw_a, raw_b, category_code "
                "FROM source_records "
                "ORDER BY id"          # ORDER BY helps with tablet-level locality
            ),
            target_table  = "final_table",
            columns       = ["id", "metric_1", "metric_2", "category", "flag"],
            conflict_cols = ["id"],
            update_cols   = ["metric_1", "metric_2", "category", "flag"],
            transform_fn  = transform_upsert,
        )

        # ── Option 2: pure INSERT (target is empty / truncated) ────────────
        # stats = pipeline.run_insert(
        #     source_query  = "SELECT id, raw_a, raw_b, category_code FROM source_records",
        #     target_table  = "final_table",
        #     columns       = ["id", "metric_1", "metric_2", "category", "flag"],
        #     transform_fn  = transform_upsert,
        # )

        # ── Option 3: MIXED I/U/D/X (source has op_flag column) ───────────
        # stats = pipeline.run_mixed(
        #     source_query  = "SELECT id, op_flag, value FROM change_log ORDER BY id",
        #     target_table  = "final_table",
        #     columns       = ["id", "computed_value"],
        #     conflict_cols = ["id"],
        #     update_cols   = ["computed_value"],
        #     id_col        = "id",
        #     transform_fn  = transform_mixed,
        # )

        # ── Option 4: pure UPDATE ──────────────────────────────────────────
        # stats = pipeline.run_update(
        #     source_query  = "SELECT new_value, record_id FROM corrections",
        #     target_table  = "final_table",
        #     set_cols      = ["computed_value"],
        #     key_cols      = ["id"],
        #     transform_fn  = lambda rows: [(r[0], r[1]) for r in rows],
        # )

        # ── Option 5: pure DELETE ──────────────────────────────────────────
        # stats = pipeline.run_delete(
        #     source_query  = "SELECT id FROM records_to_delete",
        #     target_table  = "final_table",
        #     id_col        = "id",
        #     transform_fn  = lambda rows: [r[0] for r in rows],
        # )

        log.info("=== ETL complete ===")
        log.info(stats.summary())
        return 0

    except Exception as exc:
        log.exception("ETL failed: %s", exc)
        return 1

    finally:
        log.info("Source pool stats: %s", source_pool.stats())
        log.info("Target pool stats: %s", target_pool.stats())
        source_pool.close()
        target_pool.close()
        log.info("=== Shutdown complete ===")


if __name__ == "__main__":
    sys.exit(main())
