"""
etl_pipeline.py – 16-Thread Parallel ETL Pipeline for YugabyteDB
=================================================================

Architecture
────────────

  ┌────────────────────────────────────────────────────────────────────┐
  │  Producer (main thread)                                            │
  │  • Opens a named (server-side) cursor on the source connection     │
  │  • Fetches rows in chunks of `batch_size` – never loads 250 M     │
  │    records into Python memory at once                              │
  │  • Puts (batch_id, rows) tuples into work_queue                   │
  │  • Blocks automatically when work_queue is full (back-pressure)    │
  └─────────────────────────────┬──────────────────────────────────────┘
                                │
                   queue.Queue(maxsize=queue_cap)
                   ← blocks producer when workers fall behind
                                │
  ┌─────────────────────────────▼──────────────────────────────────────┐
  │  16 Worker Threads (ThreadPoolExecutor)                            │
  │  Each worker loop:                                                 │
  │   1. Pull (batch_id, rows) from queue                             │
  │   2. Apply transform_fn(rows)  ← your ETL calculations            │
  │   3. pool.acquire() → healthy connection                          │
  │   4. bulk_op(conn, transformed_rows)  ← COPY / upsert / etc.     │
  │   5. Connection auto-returned to pool                             │
  │   6. Retry up to max_retries with exponential back-off            │
  └────────────────────────────────────────────────────────────────────┘

Key properties
──────────────
• Server-side cursor   – memory-efficient streaming; no 250 M row buffer
• LIFO connection pool – connections returned most-recently-used first
• Sentinel pattern     – None in the queue signals workers to exit cleanly
• Back-pressure        – bounded queue prevents OOM when workers are slow
• Per-batch retry      – transient DB errors (e.g. node restart) are
                         retried without losing the batch
• Graceful stop()      – sets an event; current batches finish normally
"""

from __future__ import annotations

import logging
import queue
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterator, List, Optional, Sequence, Tuple

from bulk_ops import (
    Op,
    bulk_insert_copy,
    bulk_upsert,
    bulk_update,
    bulk_delete,
    bulk_mixed,
)
from connection_pool import ResilientYBPool

log = logging.getLogger(__name__)

_SENTINEL = None   # placed in the work queue to signal each worker to stop


# ════════════════════════════════════════════════════════════════════════════
#  Result / statistics types
# ════════════════════════════════════════════════════════════════════════════

@dataclass
class BatchResult:
    """Outcome of processing one batch in one worker thread."""
    batch_id:  int
    worker:    str
    n_rows:    int
    inserted:  int = 0
    upserted:  int = 0
    updated:   int = 0
    deleted:   int = 0
    error:     Optional[str] = None
    elapsed:   float = 0.0

    @property
    def ok(self) -> bool:
        return self.error is None


@dataclass
class PipelineStats:
    """Thread-safe running totals updated by every worker."""
    processed:  int = 0
    inserted:   int = 0
    upserted:   int = 0
    updated:    int = 0
    deleted:    int = 0
    errors:     int = 0
    batches:    int = 0
    t_start:    float = field(default_factory=time.monotonic)
    t_end:      Optional[float] = None
    _lk:        threading.Lock = field(default_factory=threading.Lock, repr=False)

    def absorb(self, r: BatchResult) -> None:
        with self._lk:
            self.processed  += r.n_rows
            self.inserted   += r.inserted
            self.upserted   += r.upserted
            self.updated    += r.updated
            self.deleted    += r.deleted
            self.errors     += (0 if r.ok else 1)
            self.batches    += 1

    def elapsed_sec(self) -> float:
        return (self.t_end or time.monotonic()) - self.t_start

    def rows_per_sec(self) -> float:
        elapsed = self.elapsed_sec()
        return self.processed / elapsed if elapsed > 0 else 0.0

    def summary(self) -> str:
        return (
            f"processed={self.processed:,}  "
            f"inserted={self.inserted:,}  "
            f"upserted={self.upserted:,}  "
            f"updated={self.updated:,}  "
            f"deleted={self.deleted:,}  "
            f"errors={self.errors}  "
            f"batches={self.batches}  "
            f"elapsed={self.elapsed_sec():.1f}s  "
            f"rate={self.rows_per_sec():,.0f} rows/s"
        )


# ════════════════════════════════════════════════════════════════════════════
#  Pipeline
# ════════════════════════════════════════════════════════════════════════════

class YBETLPipeline:
    """
    Parallel ETL pipeline:

        source YugabyteDB  →  transform (Python)  →  target YugabyteDB

    Parameters
    ──────────
    source_pool   ResilientYBPool connected to the source cluster/database
    target_pool   ResilientYBPool connected to the target cluster/database
    num_workers   parallel loader threads (default: 16)
    batch_size    rows per COPY/upsert call and source-cursor fetch size
    queue_cap     max in-flight batches before producer blocks (back-pressure)
    max_retries   per-batch retry attempts on transient errors
    log_interval  log a progress line every N batches (0 = disabled)
    """

    def __init__(
        self,
        source_pool:   ResilientYBPool,
        target_pool:   ResilientYBPool,
        num_workers:   int   = 16,
        batch_size:    int   = 10_000,
        queue_cap:     int   = 64,
        max_retries:   int   = 3,
        log_interval:  int   = 200,
    ) -> None:
        self.source_pool  = source_pool
        self.target_pool  = target_pool
        self.num_workers  = num_workers
        self.batch_size   = batch_size
        self.queue_cap    = queue_cap
        self.max_retries  = max_retries
        self.log_interval = log_interval

        self._work_q:  queue.Queue[Any] = queue.Queue(maxsize=queue_cap)
        self._stop:    threading.Event  = threading.Event()
        self._stats:   PipelineStats    = PipelineStats()
        self._bid_seq: int              = 0
        self._bid_lk:  threading.Lock   = threading.Lock()

    # ── helpers ───────────────────────────────────────────────────────────

    def _next_bid(self) -> int:
        with self._bid_lk:
            self._bid_seq += 1
            return self._bid_seq

    # ── producer: stream source data ─────────────────────────────────────

    def _stream_source(
        self,
        query:       str,
        chunk_size:  int,
    ) -> Iterator[List[tuple]]:
        """
        Stream source rows using a *named* (server-side) cursor.

        A named cursor executes on the server and sends `itersize` rows at
        a time over the wire.  This means a 250 M row result set never
        lives in Python memory – only the current chunk does.

        The cursor is held open for the full duration of source streaming.
        The source connection is returned to the pool at the end.
        """
        with self.source_pool.acquire() as conn:
            cursor_name = f"etl_src_{int(time.time() * 1000)}"
            with conn.cursor(name=cursor_name) as cur:
                cur.itersize = chunk_size           # server-side fetch window
                cur.execute(query)

                batch: List[tuple] = []
                for row in cur:
                    batch.append(row)
                    if len(batch) >= chunk_size:
                        yield batch
                        batch = []
                        if self._stop.is_set():
                            log.info("Stop signal received – halting source read.")
                            return
                if batch:
                    yield batch

    # ── consumer: worker thread ───────────────────────────────────────────

    def _worker(
        self,
        target_table:  str,
        columns:       List[str],
        transform_fn:  Callable[[List[tuple]], Any],
        load_fn:       Callable[[Any, str, List[str], Any], Dict[str, int]],
    ) -> None:
        """
        Long-running worker that pulls batches from the work queue,
        transforms them, and writes to the target database.

        Each batch is retried up to max_retries times with exponential
        back-off.  Permanent failures are logged and counted; the worker
        continues with the next batch rather than crashing the thread.
        """
        name = threading.current_thread().name
        log.debug("%s started.", name)

        while not self._stop.is_set():
            # ── get a batch (2 s timeout allows checking stop flag) ────────
            try:
                item = self._work_q.get(timeout=2.0)
            except queue.Empty:
                continue

            if item is _SENTINEL:
                self._work_q.task_done()
                break

            bid, raw_batch = item
            t0  = time.monotonic()
            res = BatchResult(batch_id=bid, worker=name, n_rows=len(raw_batch))

            # ── retry loop ────────────────────────────────────────────────
            delay = 0.5
            for attempt in range(1, self.max_retries + 1):
                try:
                    # 1. Apply the caller-supplied transformation
                    transformed = transform_fn(raw_batch)

                    # 2. Acquire a healthy connection from the pool and write
                    with self.target_pool.acquire() as conn:
                        counts = load_fn(conn, target_table, columns, transformed)

                    # 3. Record counts
                    res.inserted = counts.get("inserted", 0)
                    res.upserted = counts.get("upserted", 0)
                    res.updated  = counts.get("updated",  0)
                    res.deleted  = counts.get("deleted",  0)
                    break   # success

                except Exception as exc:
                    if attempt == self.max_retries:
                        res.error = f"{type(exc).__name__}: {exc}"
                        log.error(
                            "[%s] Batch %d FAILED after %d attempts: %s\n%s",
                            name, bid, attempt, exc, traceback.format_exc(),
                        )
                    else:
                        log.warning(
                            "[%s] Batch %d attempt %d/%d: %s – retry in %.1fs",
                            name, bid, attempt, self.max_retries, exc, delay,
                        )
                        time.sleep(delay)
                        delay = min(delay * 2, 30.0)

            res.elapsed = time.monotonic() - t0
            self._stats.absorb(res)
            self._work_q.task_done()

            if res.ok:
                log.debug(
                    "[%s] Batch %d: %d rows in %.2fs",
                    name, bid, res.n_rows, res.elapsed,
                )

        log.debug("%s exiting.", name)

    # ── public run methods ────────────────────────────────────────────────

    def run_upsert(
        self,
        source_query:   str,
        target_table:   str,
        columns:        List[str],
        conflict_cols:  List[str],
        update_cols:    List[str],
        transform_fn:   Callable[[List[tuple]], List[tuple]],
    ) -> PipelineStats:
        """
        Upsert ETL: INSERT … ON CONFLICT DO UPDATE.

        Most common pattern for 250 M record loads where the target table
        already contains some records that need updating and new rows need
        inserting – all in one pass.

        transform_fn  (raw_rows) → List[tuple]  maps to `columns`
        """
        def _load(conn, table, cols, rows):
            n = bulk_upsert(
                conn, table, cols, conflict_cols, update_cols, rows, self.batch_size
            )
            return {"upserted": n}

        return self._run(source_query, target_table, columns, transform_fn, _load)

    def run_insert(
        self,
        source_query:  str,
        target_table:  str,
        columns:       List[str],
        transform_fn:  Callable[[List[tuple]], List[tuple]],
    ) -> PipelineStats:
        """
        Pure-insert ETL using COPY FROM STDIN (fastest possible path).

        Use this when the target table is empty or truncated before the run.
        transform_fn  (raw_rows) → List[tuple]  maps to `columns`
        """
        def _load(conn, table, cols, rows):
            n = bulk_insert_copy(conn, table, cols, rows, self.batch_size)
            return {"inserted": n}

        return self._run(source_query, target_table, columns, transform_fn, _load)

    def run_update(
        self,
        source_query:  str,
        target_table:  str,
        set_cols:      List[str],
        key_cols:      List[str],
        transform_fn:  Callable[[List[tuple]], List[tuple]],
    ) -> PipelineStats:
        """
        Pure-update ETL.

        transform_fn must return tuples with layout: (*set_col_values, *key_col_values)
        e.g. set_cols=["amount"], key_cols=["id"]  → row = (150.0, 42)
        """
        columns = set_cols + key_cols

        def _load(conn, table, cols, rows):
            n = bulk_update(conn, table, set_cols, key_cols, rows, self.batch_size)
            return {"updated": n}

        return self._run(source_query, target_table, columns, transform_fn, _load)

    def run_delete(
        self,
        source_query:  str,
        target_table:  str,
        id_col:        str,
        transform_fn:  Callable[[List[tuple]], List[Any]],
    ) -> PipelineStats:
        """
        Delete ETL: removes rows from target whose IDs are returned by
        source_query + transform_fn.

        transform_fn  (raw_rows) → List[id_value]
        """
        columns = [id_col]

        def _load(conn, table, cols, ids):
            n = bulk_delete(conn, table, id_col, ids, self.batch_size)
            return {"deleted": n}

        return self._run(source_query, target_table, columns, transform_fn, _load)

    def run_mixed(
        self,
        source_query:   str,
        target_table:   str,
        columns:        List[str],
        conflict_cols:  List[str],
        update_cols:    List[str],
        id_col:         str,
        transform_fn:   Callable[[List[tuple]], List[Tuple[Op, tuple]]],
    ) -> PipelineStats:
        """
        Mixed-operation ETL: each row carries an Op tag.

        transform_fn  (raw_rows) → List[Tuple[Op, data_tuple]]

        Example output from transform_fn:
            [(Op.UPSERT, (1, 'Alice', 100.0)),
             (Op.DELETE, (99,)),
             (Op.UPDATE, (200.0, 2))]
        """
        def _load(conn, table, cols, tagged_rows):
            return bulk_mixed(
                conn, table, cols, conflict_cols, update_cols,
                id_col, tagged_rows, self.batch_size,
            )

        return self._run(source_query, target_table, columns, transform_fn, _load)

    # ── core orchestration ────────────────────────────────────────────────

    def _run(
        self,
        source_query:  str,
        target_table:  str,
        columns:       List[str],
        transform_fn:  Callable,
        load_fn:       Callable,
    ) -> PipelineStats:
        """
        Core orchestration loop.

        1. Start `num_workers` long-running worker threads in a pool.
        2. Stream source rows in chunks → push to bounded work queue.
        3. Workers consume from the queue concurrently.
        4. Sentinel values drain the workers cleanly.
        5. Wait for all tasks to complete (queue.join()).
        """
        # Reset for re-use
        self._stats  = PipelineStats()
        self._stop.clear()

        log.info(
            "ETL start  target=%s  workers=%d  batch=%d  queue_cap=%d",
            target_table, self.num_workers, self.batch_size, self.queue_cap,
        )

        with ThreadPoolExecutor(
            max_workers=self.num_workers,
            thread_name_prefix="yb-etl",
        ) as executor:

            # ── launch long-running workers ────────────────────────────────
            worker_futures = [
                executor.submit(
                    self._worker, target_table, columns, transform_fn, load_fn
                )
                for _ in range(self.num_workers)
            ]

            # ── producer: feed the queue ───────────────────────────────────
            total_queued = 0
            try:
                for chunk in self._stream_source(source_query, self.batch_size):
                    # put() blocks when the queue is full → natural back-pressure
                    self._work_q.put((self._next_bid(), chunk))
                    total_queued += 1

                    if self.log_interval and total_queued % self.log_interval == 0:
                        log.info(
                            "Progress  queued=%d  %s",
                            total_queued, self._stats.summary(),
                        )

            except Exception as exc:
                log.error("Producer error: %s", exc, exc_info=True)
                self._stop.set()

            finally:
                # One sentinel per worker thread
                for _ in range(self.num_workers):
                    self._work_q.put(_SENTINEL)

            # ── wait for every task to be acknowledged ────────────────────
            self._work_q.join()

            # ── surface any worker-level exceptions ───────────────────────
            for fut in worker_futures:
                try:
                    fut.result()
                except Exception as exc:
                    log.error("Worker future raised: %s", exc)

        self._stats.t_end = time.monotonic()
        log.info("ETL complete  %s", self._stats.summary())
        return self._stats

    # ── graceful stop ─────────────────────────────────────────────────────

    def stop(self) -> None:
        """
        Signal all workers to stop after finishing their current batch.
        The pipeline will drain the queue and commit in-progress work before
        terminating.  Call this from a signal handler or KeyboardInterrupt.
        """
        log.info("Stop requested – draining in-progress batches…")
        self._stop.set()
