"""
connection_pool.py – Resilient YugabyteDB Connection Pool
==========================================================

Design goals
────────────
1. LIFO queue  – most-recently-used connections are reused first, minimising
   the chance that a connection sits idle long enough to be killed by a
   firewall / load-balancer.

2. Pre-acquire validation – every connection is checked before being handed
   to a caller.  A cheap status-flag check runs every time; a SELECT-1 ping
   only fires when the connection has been idle > ping_idle_threshold_sec.

3. Dead-connection replacement – if a connection fails the health check,
   it is discarded and a fresh one is created transparently, so callers
   never see a "connection already closed" error.

4. On-return replacement – if a connection dies *during* use, the pool
   creates a replacement before releasing the slot so pool size never
   drops below minimum.

5. Semaphore-gated concurrency – a threading.Semaphore(pool_max) ensures
   at most `pool_max` connections are checked out simultaneously; callers
   block with a configurable timeout rather than crashing.

6. Background sweep – a daemon thread periodically pings every idle
   connection and replenishes stale ones, keeping the pool healthy even
   during long quiet periods.

7. Smart Driver / multi-host failover – the connection factory passes all
   5 node addresses plus load_balance=true.  If one node is unreachable,
   the Smart Driver (or psycopg2 ≥ 2.9 multi-host) connects to another
   automatically.  Exponential-backoff retry at the factory level covers
   transient failures.
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Iterator, Optional

# ── Driver detection ─────────────────────────────────────────────────────────
# Prefer the YugabyteDB Smart Driver (yb_psycopg2).
# Install: pip install yb-psycopg2
# It exposes the same API as psycopg2 but adds load_balance / topology_keys
# support and maintains an internal topology cache for live node discovery.
try:
    import yb_psycopg2 as _pg          # Smart Driver
    _SMART_DRIVER = True
    _DRIVER_LABEL = "yb_psycopg2 (Smart Driver)"
except ImportError:
    import psycopg2 as _pg             # Standard psycopg2 ≥ 2.9 fallback
    _SMART_DRIVER = False
    _DRIVER_LABEL = "psycopg2 (standard – install yb-psycopg2 for Smart Driver)"

from config import DBConfig

log = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════
#  Internal connection wrapper
# ════════════════════════════════════════════════════════════════════════════

@dataclass
class _Conn:
    """
    Wraps a raw psycopg2 connection with metadata for pool bookkeeping.

    Health-check strategy
    ─────────────────────
    • is_closed()  – reads raw.closed (local flag, zero overhead)
    • has_error()  – checks transaction status for STATUS_INTRANS_INERROR
    • ping()       – executes SELECT 1, rolls back (one network round-trip)
    • is_healthy() – fast path unless connection has been idle too long
    """

    raw:            object            # psycopg2 connection
    uid:            int               # unique pool-assigned ID
    created:        float = field(default_factory=time.monotonic)
    last_returned:  float = field(default_factory=time.monotonic)

    # ── cheap local checks ────────────────────────────────────────────────

    def is_closed(self) -> bool:
        try:
            return bool(self.raw.closed)
        except Exception:
            return True

    def has_error(self) -> bool:
        """True if the connection is stuck in a failed transaction."""
        try:
            # STATUS_INTRANS_INERROR = 4 in psycopg2
            return self.raw.status == 4
        except Exception:
            return True

    def idle_seconds(self) -> float:
        return time.monotonic() - self.last_returned

    # ── network ping ──────────────────────────────────────────────────────

    def ping(self) -> bool:
        """
        Round-trip health check.
        Rolls back afterward so the connection is in a clean idle state.
        """
        try:
            with self.raw.cursor() as cur:
                cur.execute("SELECT 1")
            self.raw.rollback()
            return True
        except Exception:
            return False

    # ── combined health check ─────────────────────────────────────────────

    def is_healthy(self, ping_threshold_sec: float, force_ping: bool = False) -> bool:
        """
        Two-tier check:
          1. Cheap local flags (always run).
          2. Network ping – only when idle > threshold OR force_ping=True.
        """
        if self.is_closed() or self.has_error():
            return False
        if force_ping or self.idle_seconds() > ping_threshold_sec:
            return self.ping()
        return True

    # ── cleanup ───────────────────────────────────────────────────────────

    def rollback_quietly(self):
        try:
            self.raw.rollback()
        except Exception:
            pass

    def close_quietly(self):
        try:
            if not self.raw.closed:
                self.raw.close()
        except Exception:
            pass


# ════════════════════════════════════════════════════════════════════════════
#  Pool
# ════════════════════════════════════════════════════════════════════════════

class ResilientYBPool:
    """
    Thread-safe, self-healing connection pool for YugabyteDB.

    Quick start
    ───────────
        cfg  = DBConfig(hosts=[…], database="mydb", …)
        pool = ResilientYBPool(cfg)

        with pool.acquire() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT …")
            conn.commit()

        pool.close()

    The pool is safe to share across any number of threads.
    """

    # ── construction ──────────────────────────────────────────────────────

    def __init__(self, cfg: DBConfig) -> None:
        self._cfg   = cfg
        self._dsn   = self._build_dsn(cfg)
        self._min   = cfg.pool_min
        self._max   = cfg.pool_max
        self._ping_thr  = cfg.ping_idle_threshold_sec
        self._acq_tout  = cfg.acquire_timeout
        self._closed    = False

        # Semaphore: at most pool_max concurrent checkouts
        self._slots = threading.Semaphore(self._max)

        # LIFO queue (unbounded – semaphore is the capacity control)
        self._idle: queue.LifoQueue[_Conn] = queue.LifoQueue()

        # Bookkeeping
        self._lock    = threading.Lock()
        self._uid_seq = 0
        self._stats   = {
            "created": 0, "acquired": 0, "released": 0,
            "replaced": 0, "ping_failures": 0, "errors": 0,
        }

        # Pre-warm
        log.info(
            "Initialising pool [driver=%s, min=%d, max=%d, nodes=%s]",
            _DRIVER_LABEL, self._min, self._max, ",".join(cfg.hosts),
        )
        for _ in range(self._min):
            c = self._make_connection()
            self._idle.put(c)

        # Background health sweep (daemon – dies with the process)
        self._sweeper = threading.Thread(
            target=self._sweep_loop,
            name="yb-pool-sweeper",
            daemon=True,
        )
        self._sweeper.start()
        log.info("Pool ready (%d connections pre-warmed).", self._min)

    # ── DSN builder ───────────────────────────────────────────────────────

    @staticmethod
    def _build_dsn(cfg: DBConfig) -> dict:
        """
        Strip Smart-Driver-only params when using plain psycopg2 to avoid
        'invalid connection option: load_balance' errors.
        """
        dsn = cfg.dsn()
        if not _SMART_DRIVER:
            dsn.pop("load_balance",   None)
            dsn.pop("topology_keys",  None)
        return dsn

    # ── connection factory ────────────────────────────────────────────────

    def _next_uid(self) -> int:
        with self._lock:
            self._uid_seq += 1
            return self._uid_seq

    def _make_connection(self) -> _Conn:
        """
        Create one physical connection with exponential-backoff retries.

        With yb_psycopg2 (Smart Driver)
        ─────────────────────────────────
        The driver maintains an internal topology map of live nodes.  On
        each connect() call it picks the least-loaded live node.  If that
        node fails mid-attempt, it automatically retries with another.

        With plain psycopg2 ≥ 2.9 (comma-separated hosts)
        ───────────────────────────────────────────────────
        psycopg2 tries each host in order until one succeeds.  This gives
        basic failover but no active load-balancing.
        """
        delay = self._cfg.reconnect_backoff_base
        last_exc: Optional[Exception] = None

        for attempt in range(1, self._cfg.reconnect_retries + 1):
            try:
                raw = _pg.connect(**self._dsn)
                raw.autocommit = False          # explicit transaction control for ETL

                uid = self._next_uid()
                with self._lock:
                    self._stats["created"] += 1

                log.debug("Connection uid=%d created (attempt %d).", uid, attempt)
                return _Conn(raw=raw, uid=uid)

            except Exception as exc:
                last_exc = exc
                log.warning(
                    "Connect attempt %d/%d failed: %s",
                    attempt, self._cfg.reconnect_retries, exc,
                )
                if attempt < self._cfg.reconnect_retries:
                    time.sleep(delay)
                    delay = min(delay * 2, 30.0)

        raise ConnectionError(
            f"Cannot connect to YugabyteDB after "
            f"{self._cfg.reconnect_retries} attempts. Last error: {last_exc}"
        )

    # ── acquire / release (public API) ────────────────────────────────────

    @contextmanager
    def acquire(self) -> Iterator[object]:
        """
        Context manager – yields a *validated* raw psycopg2 connection.

        Guarantees
        ──────────
        • The connection is alive when yielded (cheap check + conditional ping).
        • On normal exit: connection is rolled back and returned to the pool.
        • On error exit: connection is rolled back and returned if still alive;
          otherwise it is closed and a fresh replacement is added to the pool.
        • The pool semaphore is always released – no slot leaks.

        Usage
        ─────
            with pool.acquire() as conn:
                conn.cursor().execute(…)
                conn.commit()     # caller commits; pool does rollback on return
        """
        if self._closed:
            raise RuntimeError("Pool is closed.")

        if not self._slots.acquire(timeout=self._acq_tout):
            raise TimeoutError(
                f"Pool exhausted: could not acquire a connection "
                f"within {self._acq_tout}s "
                f"(pool_max={self._max}, currently all slots in use)."
            )

        c: Optional[_Conn] = None
        try:
            c = self._checkout_healthy()
            with self._lock:
                self._stats["acquired"] += 1

            yield c.raw      # ← caller works with the raw connection here

        except Exception:
            # Rollback any partial work; mark dead if rollback fails
            if c is not None:
                try:
                    c.raw.rollback()
                except Exception:
                    c.close_quietly()
                    c = None          # triggers replacement in _checkin
            raise

        finally:
            self._checkin(c)
            self._slots.release()

    # ── internal checkout / checkin ───────────────────────────────────────

    def _checkout_healthy(self) -> _Conn:
        """
        Pop an idle connection and validate it.
        Replaces dead connections up to 3 times before giving up.
        Falls back to creating a new connection if the idle queue is empty
        (legitimate when near pool_max concurrency).
        """
        for attempt in range(3):
            # ── try to get an idle connection ─────────────────────────────
            try:
                c = self._idle.get_nowait()
            except queue.Empty:
                # All connections are checked out → create an extra one.
                # The semaphore already gated us, so this is within pool_max.
                log.debug("Idle queue empty – creating overflow connection.")
                return self._make_connection()

            # ── validate ──────────────────────────────────────────────────
            if c.is_healthy(self._ping_thr):
                return c

            # ── dead – replace ────────────────────────────────────────────
            log.warning(
                "Dead connection uid=%d detected on acquire (idle=%.1fs). Replacing…",
                c.uid, c.idle_seconds(),
            )
            c.close_quietly()
            with self._lock:
                self._stats["ping_failures"] += 1
                self._stats["replaced"] += 1

            try:
                return self._make_connection()
            except Exception as exc:
                log.error(
                    "Replacement attempt %d/3 failed: %s. "
                    "Retrying with next idle connection…", attempt + 1, exc,
                )

        raise ConnectionError(
            "Could not obtain a healthy connection from the pool after 3 attempts."
        )

    def _checkin(self, c: Optional[_Conn]) -> None:
        """
        Return `c` to the idle queue.
        If `c` is None (died during use) or is found dead, create a replacement
        so the pool never shrinks below minimum.
        """
        if c is not None and not c.is_closed() and not c.has_error():
            try:
                c.rollback_quietly()       # ensure clean transaction state
                c.last_returned = time.monotonic()
                self._idle.put_nowait(c)   # unbounded LifoQueue – never blocks
                with self._lock:
                    self._stats["released"] += 1
                return
            except Exception:
                c.close_quietly()

        # Connection is dead – create a replacement so pool size stays stable
        log.info("Adding replacement connection to pool after dead checkin.")
        try:
            fresh = self._make_connection()
            self._idle.put_nowait(fresh)
            with self._lock:
                self._stats["replaced"] += 1
        except Exception as exc:
            log.error(
                "Could not replenish pool after dead connection – "
                "pool may be one short: %s", exc,
            )
            with self._lock:
                self._stats["errors"] += 1

    # ── background health sweep ───────────────────────────────────────────

    def _sweep_loop(self) -> None:
        """Daemon thread: validate all idle connections on a fixed schedule."""
        while not self._closed:
            time.sleep(self._cfg.health_sweep_interval_sec)
            if not self._closed:
                self._sweep()

    def _sweep(self) -> None:
        """
        Drain the idle queue, force-ping every connection, discard dead ones,
        and refill to pool_min.  Runs without holding the slot semaphore so
        it cannot starve active workers.
        """
        conns: list[_Conn] = []
        while True:
            try:
                conns.append(self._idle.get_nowait())
            except queue.Empty:
                break

        healthy, dead_count = [], 0
        for c in conns:
            if c.is_healthy(0, force_ping=True):   # force_ping=True in sweep
                healthy.append(c)
            else:
                c.close_quietly()
                dead_count += 1

        # Replenish to minimum
        shortfall = max(0, self._min - len(healthy))
        added = 0
        for _ in range(shortfall):
            try:
                healthy.append(self._make_connection())
                added += 1
            except Exception as exc:
                log.error("Sweep: could not refill pool: %s", exc)

        for c in healthy:
            self._idle.put_nowait(c)

        if dead_count or added:
            log.info(
                "Pool sweep: %d dead replaced, %d added to reach minimum=%d. "
                "Idle queue now: %d.",
                dead_count, added, self._min, self._idle.qsize(),
            )

    # ── diagnostics ───────────────────────────────────────────────────────

    def stats(self) -> dict:
        with self._lock:
            return {
                **self._stats,
                "idle_queue_size": self._idle.qsize(),
                "driver":          _DRIVER_LABEL,
            }

    def __repr__(self) -> str:
        return (
            f"ResilientYBPool(min={self._min}, max={self._max}, "
            f"idle={self._idle.qsize()}, driver={_DRIVER_LABEL!r})"
        )

    # ── shutdown ──────────────────────────────────────────────────────────

    def close(self) -> None:
        """
        Graceful shutdown: close every idle connection and stop the sweeper.
        Active connections (checked out) are left to their callers.
        """
        self._closed = True
        closed_count = 0
        while True:
            try:
                self._idle.get_nowait().close_quietly()
                closed_count += 1
            except queue.Empty:
                break
        log.info(
            "Pool closed: %d idle connections closed. Final stats: %s",
            closed_count, self.stats(),
        )
