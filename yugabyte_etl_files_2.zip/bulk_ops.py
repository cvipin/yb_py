"""
bulk_ops.py – High-throughput Bulk Operations for YugabyteDB
=============================================================

Operation          Function                  Mechanism
─────────────────────────────────────────────────────────────────────────────
INSERT             bulk_insert_copy()        COPY FROM STDIN  (fastest path)
UPSERT             bulk_upsert()             INSERT … ON CONFLICT DO UPDATE
UPDATE             bulk_update()             UPDATE … FROM (VALUES …)
DELETE             bulk_delete()             DELETE … WHERE id = ANY(%s)
Mixed I/U/D/X      bulk_mixed()              per-row Op dispatch

All functions accept a live psycopg2 connection, execute within a single
transaction, and commit on success.  They do NOT rollback on error – the
caller (or the pool's context manager) is responsible for that.

COPY text-format escaping
─────────────────────────
PostgreSQL's TEXT format uses:
  • TAB  as field delimiter
  • \\N   as NULL marker
  • \\\\  for a literal backslash in data
  • \\t   for a literal tab in a string value
  • \\n / \\r for embedded newlines

_encode_copy_field() handles all of these so no data value can corrupt
the COPY stream.

Batch sizes
────────────
The defaults below are starting points for YugabyteDB with RF=3.
Tune them based on row width and cluster throughput.  For narrow rows
(a few integers) you can go much higher; for wide rows with JSON/text
columns, go lower.
"""

from __future__ import annotations

import io
import logging
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, Tuple

import psycopg2.extras as _extras

log = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════
#  Operation tag
# ════════════════════════════════════════════════════════════════════════════

class Op(Enum):
    INSERT = "I"
    UPDATE = "U"
    DELETE = "D"
    UPSERT = "X"   # INSERT … ON CONFLICT DO UPDATE


# ════════════════════════════════════════════════════════════════════════════
#  Internal helpers
# ════════════════════════════════════════════════════════════════════════════

_NULL_MARKER = r"\N"

def _encode_copy_field(val: Any) -> str:
    """
    Encode one Python value to a safe PostgreSQL TEXT-format field.

    None  →  \\N  (PostgreSQL TEXT NULL marker)
    Other →  str(val) with backslash / tab / newline / CR escaped
    """
    if val is None:
        return _NULL_MARKER
    s = str(val)
    s = s.replace("\\", "\\\\")   # must be first
    s = s.replace("\t",  "\\t")
    s = s.replace("\n",  "\\n")
    s = s.replace("\r",  "\\r")
    return s


def _copy_buffer(rows: Sequence[tuple]) -> io.StringIO:
    """
    Serialise a list of tuples into an in-memory TAB-delimited TEXT buffer
    suitable for COPY FROM STDIN.
    """
    buf = io.StringIO()
    for row in rows:
        buf.write("\t".join(_encode_copy_field(v) for v in row))
        buf.write("\n")
    buf.seek(0)
    return buf


# ════════════════════════════════════════════════════════════════════════════
#  Public API
# ════════════════════════════════════════════════════════════════════════════

def bulk_insert_copy(
    conn,
    table:       str,
    columns:     List[str],
    rows:        Sequence[tuple],
    batch_size:  int = 25_000,
) -> int:
    """
    Fastest INSERT path: streams data via PostgreSQL COPY FROM STDIN.

    COPY bypasses the SQL parser/planner and skips per-row lock overhead,
    making it 5-20× faster than multi-row INSERT for large volumes.
    YugabyteDB fully supports COPY on YSQL tables.

    Rows are split into batches to avoid building one enormous buffer.
    Each batch runs inside the same connection transaction; a single
    conn.commit() is issued at the end.

    Parameters
    ──────────
    conn        raw psycopg2 connection (autocommit=False)
    table       target table name (schema-qualified if needed)
    columns     ordered list of column names matching row tuple positions
    rows        sequence of tuples to insert
    batch_size  rows per COPY call (tune for your row width)

    Returns total rows inserted.
    """
    if not rows:
        return 0

    col_list = ", ".join(columns)
    copy_sql = (
        f"COPY {table} ({col_list}) "
        f"FROM STDIN WITH (FORMAT TEXT, DELIMITER E'\\t', NULL '\\N')"
    )

    total = 0
    with conn.cursor() as cur:
        for start in range(0, len(rows), batch_size):
            chunk = rows[start : start + batch_size]
            cur.copy_expert(copy_sql, _copy_buffer(chunk))
            total += len(chunk)

    conn.commit()
    log.debug("bulk_insert_copy → %d rows into %s", total, table)
    return total


def bulk_upsert(
    conn,
    table:         str,
    columns:       List[str],
    conflict_cols: List[str],
    update_cols:   List[str],
    rows:          Sequence[tuple],
    batch_size:    int = 10_000,
) -> int:
    """
    INSERT … ON CONFLICT (conflict_cols) DO UPDATE SET update_cols = EXCLUDED.*

    Uses psycopg2.extras.execute_values which builds a single
    INSERT … VALUES (…),(…),… statement per batch, far more efficient
    than individual INSERTs.

    conflict_cols   columns forming the unique / primary-key constraint
    update_cols     columns to overwrite on conflict (usually all non-key cols)
    """
    if not rows:
        return 0

    col_list  = ", ".join(columns)
    conf_list = ", ".join(conflict_cols)
    upd_list  = ", ".join(f"{c} = EXCLUDED.{c}" for c in update_cols)

    sql = (
        f"INSERT INTO {table} ({col_list}) "
        f"VALUES %s "
        f"ON CONFLICT ({conf_list}) "
        f"DO UPDATE SET {upd_list}"
    )

    total = 0
    with conn.cursor() as cur:
        for start in range(0, len(rows), batch_size):
            chunk = rows[start : start + batch_size]
            _extras.execute_values(cur, sql, chunk, page_size=batch_size)
            total += len(chunk)

    conn.commit()
    log.debug("bulk_upsert → %d rows into %s", total, table)
    return total


def bulk_update(
    conn,
    table:      str,
    set_cols:   List[str],
    key_cols:   List[str],
    rows:       Sequence[tuple],
    batch_size: int = 10_000,
) -> int:
    """
    Batch UPDATE using UPDATE … FROM (VALUES …) AS src(…) WHERE key match.

    This avoids a temp-table creation/drop cycle per batch.  The VALUES
    list is expanded by execute_values into a single SQL statement, which
    YugabyteDB executes as one distributed transaction per batch.

    Row tuple layout: (*set_col_values, *key_col_values)
    Example:
        set_cols  = ["amount", "status"]
        key_cols  = ["order_id"]
        row tuple = (150.00, "paid", 42)   # amount, status, order_id
    """
    if not rows:
        return 0

    all_cols    = set_cols + key_cols
    # Alias every column in the VALUES sub-select to avoid name collision
    # with the target table columns inside the UPDATE clause.
    val_aliases = ", ".join(f"v_{c}" for c in all_cols)
    set_clause  = ", ".join(f"{c} = src.v_{c}" for c in set_cols)
    where_clause = " AND ".join(f"t.{c} = src.v_{c}" for c in key_cols)

    sql = (
        f"UPDATE {table} AS t "
        f"SET {set_clause} "
        f"FROM (VALUES %s) AS src({val_aliases}) "
        f"WHERE {where_clause}"
    )

    total = 0
    with conn.cursor() as cur:
        for start in range(0, len(rows), batch_size):
            chunk = rows[start : start + batch_size]
            _extras.execute_values(cur, sql, chunk, page_size=batch_size)
            total += len(chunk)

    conn.commit()
    log.debug("bulk_update → %d rows in %s", total, table)
    return total


def bulk_delete(
    conn,
    table:      str,
    id_col:     str,
    ids:        Sequence[Any],
    batch_size: int = 25_000,
) -> int:
    """
    DELETE FROM table WHERE id_col = ANY(%s)

    Passing the IDs as a Python list lets psycopg2 convert it to a PG
    array, which the planner can use with an index scan (no seq-scan).
    Much faster than IN (…, …, …) for large ID sets.
    """
    if not ids:
        return 0

    sql   = f"DELETE FROM {table} WHERE {id_col} = ANY(%s)"
    total = 0

    with conn.cursor() as cur:
        for start in range(0, len(ids), batch_size):
            chunk = list(ids[start : start + batch_size])
            cur.execute(sql, (chunk,))
            total += cur.rowcount

    conn.commit()
    log.debug("bulk_delete → %d rows from %s", total, table)
    return total


def bulk_mixed(
    conn,
    table:         str,
    columns:       List[str],
    conflict_cols: List[str],
    update_cols:   List[str],
    id_col:        str,
    tagged_rows:   Sequence[Tuple[Op, tuple]],
    batch_size:    int = 10_000,
) -> Dict[str, int]:
    """
    Dispatch rows to INSERT / UPDATE / DELETE / UPSERT based on per-row Op tag.

    tagged_rows – list of (Op, data_tuple) pairs.
        Op.INSERT / Op.UPSERT   → data_tuple maps to `columns`
        Op.UPDATE               → data_tuple maps to set_cols + key_cols
                                  (key_cols are taken from conflict_cols)
        Op.DELETE               → data_tuple[0] is the ID value

    Returns a dict with keys "inserted", "upserted", "updated", "deleted".

    All four operation types are executed within the same database connection
    but in separate SQL statements (each commits individually).  Order of
    execution: INSERT → UPSERT → UPDATE → DELETE.
    """
    inserts: List[tuple]  = []
    upserts: List[tuple]  = []
    updates: List[tuple]  = []
    delete_ids: List[Any] = []

    for op, data in tagged_rows:
        if   op == Op.INSERT: inserts.append(data)
        elif op == Op.UPSERT: upserts.append(data)
        elif op == Op.UPDATE: updates.append(data)
        elif op == Op.DELETE: delete_ids.append(data[0] if isinstance(data, (tuple, list)) else data)

    results: Dict[str, int] = {
        "inserted": 0, "upserted": 0, "updated": 0, "deleted": 0,
    }

    if inserts:
        results["inserted"] = bulk_insert_copy(
            conn, table, columns, inserts, batch_size
        )
    if upserts:
        results["upserted"] = bulk_upsert(
            conn, table, columns, conflict_cols, update_cols, upserts, batch_size
        )
    if updates:
        set_c = [c for c in columns if c not in conflict_cols]
        results["updated"] = bulk_update(
            conn, table, set_c, conflict_cols, updates, batch_size
        )
    if delete_ids:
        results["deleted"] = bulk_delete(
            conn, table, id_col, delete_ids, batch_size
        )

    return results
